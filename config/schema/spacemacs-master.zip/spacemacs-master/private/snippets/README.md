# Private directory for Yasnippets snippets

The content of this directory is ignored by Git. This is the default place
where to store your private yasnippets.

This path will be loaded automatically and used whenever Yasnippets loads.
